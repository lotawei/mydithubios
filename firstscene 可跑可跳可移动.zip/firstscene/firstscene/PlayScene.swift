//
//  GameScene.swift
//  firstscene
//
//  Created by lw on 16/4/12.
//  Copyright (c) 2016年 lw. All rights reserved.
//

import SpriteKit

//
//  PlayScene.swift
//  iobb
//
//  Created by lotawei on 16/4/4.
//  Copyright © 2016年 wl. All rights reserved.
//

import UIKit
import SpriteKit


class PlayScene: SKScene,UIGestureRecognizerDelegate,WlHumanprotocol {
    
    //跳跃手势
    var    jumpswip:UISwipeGestureRecognizer!
    //向左移动
       var    leftswip:UISwipeGestureRecognizer!
    //向右移动
       var    rightswip:UISwipeGestureRecognizer!
    //向下蹲
       var    downswip:UISwipeGestureRecognizer!
    var   iscreate=false
    var   lasttime:NSTimeInterval=0
    var   dt:NSTimeInterval=0
    var   backgroud:SKNode!
    var   padding:CGFloat=20
    //通过这个变量停止动画
    var    isstopanimation=true

  
    
    var    wlhuman:WLHuman!
    //地平线
    var    groundline:SKSpriteNode!
      var    endgroundline:SKSpriteNode!
    //第一个矮的方块
    
    var    barrier:SKSpriteNode!
    //第二个的方块
    
    var    midbarrier:SKSpriteNode!
    //弹簧
    var     spring:SKSpriteNode!
    //三个奖励星星的
    var     s1:SKSpriteNode!
    var     s2:SKSpriteNode!
     var     s3:SKSpriteNode!
    //传送门
    var     door:SKSpriteNode!
    override  func didMoveToView(view: SKView) {
        self.size=view.frame.size
        
        
        createcontent()
        
        
    }
    
    
    
    func   createcontent()
    {
        if  iscreate {
            
            return
        }
        
        //页面内容的设置
        backgroud=SKNode()
        
        backgroud.zPosition=0
        backgroud.name="backgroud"
        let   backsprite=SKSpriteNode(imageNamed: "backgroud")
        backsprite.name="backsprite"
        backsprite.anchorPoint=CGPointMake(0, 0)
        backsprite.zPosition=1
        backsprite.position=CGPointZero
        backgroud.addChild(backsprite)
        
        
        self.backgroundColor=UIColor.whiteColor()
        
        
        wlhuman=WLHuman()
        wlhuman.physicsBody=SKPhysicsBody(rectangleOfSize: wlhuman.size)
        wlhuman.physicsBody?.dynamic=true
        self.physicsWorld.speed=0.3
        
        wlhuman.name="wlhuman"
        wlhuman.zPosition=7
        print("sadasd"+"\(wlhuman.size)")
        wlhuman.anchorPoint=CGPointMake(0.5, 1)
        wlhuman.position=CGPointMake(CGRectGetMidX((view?.frame)!),CGRectGetMidY((view?.frame)!)+wlhuman.size.height+padding)
        print(wlhuman.size)
        wlhuman.standaction()
        backgroud.addChild(wlhuman)
        addChild(backgroud)
        groundline=SKSpriteNode(imageNamed: "groudline")
        groundline.anchorPoint=CGPointZero
        groundline.zPosition=2
        groundline.position=CGPointMake(0, CGRectGetMidY((view?.frame)!))
        backgroud.addChild(groundline)
        
        barrier=SKSpriteNode(imageNamed: "smallbarrier")
        barrier.anchorPoint=CGPointMake(0.5, 1)
        barrier.zPosition=2
        print(barrier.size)
        barrier.position=CGPointMake(CGRectGetMaxX(groundline.frame)-padding*6,groundline.position.y+barrier.size.height)
        backgroud.addChild(barrier)
        
        
        midbarrier=SKSpriteNode(imageNamed: "midbarrier")
        midbarrier.anchorPoint=CGPointMake(0.5, 1)
        midbarrier.zPosition=2
        print(midbarrier.size)
        midbarrier.position=CGPointMake(barrier.position.x+barrier.size.width+padding,groundline.position.y+midbarrier.size.height)
        backgroud.addChild(midbarrier)
        
        
        spring = SKSpriteNode(imageNamed: "spring")
        spring.anchorPoint=CGPointMake(0.5, 1)
        spring.zPosition=2
        print(spring.size)
        spring.position=CGPointMake(CGRectGetMaxX( groundline.frame)+spring.size.width/2.0,groundline.position.y)
        backgroud.addChild(spring)
        
        
        s1 = SKSpriteNode(imageNamed: "star")
        s1.anchorPoint=CGPointMake(0.5, 1)
        s1.zPosition=2
        print(s1.size)
        s1.position=CGPointMake(spring.position.x,spring.position.y+midbarrier.size.height+WLHuman.jumpvalue)
        backgroud.addChild(s1)
        s2 = SKSpriteNode(imageNamed: "star")
        s2.anchorPoint=CGPointMake(0.5, 1)
        s2.zPosition=2
        print(s1.size)
        s2.position=CGPointMake(CGRectGetMaxX(spring.frame)+WLHuman.jumpvalue*3,spring.position.y+s2.size.height)
        backgroud.addChild(s2)
        s3 = SKSpriteNode(imageNamed: "star")
        s3.anchorPoint=CGPointMake(0.5, 1)
        s3.zPosition=2
        
        s3.position=CGPointMake(s2.position.x+s2.size.width+padding,spring.position.y+s2.size.height)
        backgroud.addChild(s3)
        
        
        door  = SKSpriteNode(imageNamed: "door")
      
       door.anchorPoint=CGPointMake(0.5, 1)
        door.zPosition=5
        
        door.position=CGPointMake(CGRectGetMaxX(s3.frame)+padding*2,groundline.position.y+door.size.height)
        backgroud.addChild(door)
        
        
        
        endgroundline  = SKSpriteNode(imageNamed: "groudline")
        
        endgroundline.anchorPoint=CGPointMake(0,0)
        endgroundline.zPosition=2
        
        endgroundline.position=CGPointMake(CGRectGetMinX(s2.frame),groundline.position.y)
        backgroud.addChild(endgroundline)
        
        
        
        jumpswip=UISwipeGestureRecognizer(target: self, action: "guestureaction:")
        
        jumpswip.direction=UISwipeGestureRecognizerDirection.Up
        
        self.view!.addGestureRecognizer(jumpswip)
        downswip=UISwipeGestureRecognizer(target: self, action: "guestureaction:")
        
        downswip.direction=UISwipeGestureRecognizerDirection.Down
        
        self.view!.addGestureRecognizer(downswip)
        leftswip=UISwipeGestureRecognizer(target: self, action: "guestureaction:")
        
        leftswip.direction=UISwipeGestureRecognizerDirection.Left

        self.view!.addGestureRecognizer(leftswip)
        rightswip=UISwipeGestureRecognizer(target: self, action: "guestureaction:")
        
        rightswip.direction=UISwipeGestureRecognizerDirection.Right
        
        self.view!.addGestureRecognizer(rightswip)
        
        //设置物理边界
        self.backgroud.physicsBody=SKPhysicsBody(edgeFromPoint:CGPointMake(groundline.position.x, groundline.position.y+wlhuman.size.height/2), toPoint: CGPointMake(groundline.position.x+groundline.size.width, groundline.position.y+wlhuman.size.height/2))
        
        
        
       
        iscreate=true
        
    }
    
    //实现即将跳跃的代理因为这里不像左右移动 这里我们的任务他的位置实际是要发生变化的
    func  humanwilljump() -> CGPoint {
        
         return  CGPointMake(wlhuman.position.x,  wlhuman.position.y+WLHuman.jumpvalue)
    }
//    func  humanwilldown(huaman: WLHuman) {
//        wlhuman.delegate=self
//        
//        print("去实现下蹲的动画")
//    }
    func   humanwillleft()->CGPoint {
      
        return   wlhuman.position
        
    }
    func   humanwillright()->CGPoint {
          return   wlhuman.position
    }
  override  func  update(currentTime: NSTimeInterval) {
          print(wlhuman.position.y)
    }
    
    func  guestureaction(gesture:UISwipeGestureRecognizer)
    {
    
        let    atype=gesture.direction
        
        if   atype==UISwipeGestureRecognizerDirection.Up
        {
        
            wlhuman.delegate=self
            wlhuman.jumpaction()
          
            
        }
        else   if atype==UISwipeGestureRecognizerDirection.Down

        {
            print("move down")
           
        }
        else   if atype==UISwipeGestureRecognizerDirection.Right
            
        {
            
                 wlhuman.delegate=self
            
                wlhuman.turnrightaction()
                allcontentmoveleft()
            
        }
        else   if atype==UISwipeGestureRecognizerDirection.Left
            
        {
            wlhuman.delegate=self
            wlhuman.turnleftaction()
            allcontentmoveright()
        }
        
        
    }
    func    allcontentmoveleft()
    {
     
      let    nodes=backgroud.children
      let    backsp=backgroud.childNodeWithName("backsprite") as! SKSpriteNode
    if   backsp.position.x < -1000
        {
            return
        }

        for  anode in nodes
        
        {
            if  !anode.isKindOfClass(WLHuman)
            {
                let    contentnode=anode  as! SKSpriteNode
                contentnode.position.x-=10
            }
         
        }
     
    }
    func    allcontentmoveright()
    {
        
       let   nodes=backgroud.children
       let    backsp=backgroud.childNodeWithName("backsprite") as! SKSpriteNode
        if   backsp.position.x>=0
        {
            return
        }
        
        for  anode in nodes
        {
            if  !anode.isKindOfClass(WLHuman)
            {
                
                let    contentnode=anode  as! SKSpriteNode
                contentnode.position.x+=10
            }
        }
    }
    
    
}



//    func    leftaction(gesture:UILongPressGestureRecognizer)
//    {

//         let   position=wlhuman.position
//         if    position.x>wlhuman.size.width/2.0+10
//         {
//
//            wlhuman.removeAllActions()
//                                wlhuman.runAction(SKAction.group([                        SKAction.moveToX(position.x-movespeed, duration:2/10),SKAction.animateWithTextures(wlhuman.turnleftframe , timePerFrame:2/30)
//
//
//
//                                    ]), completion: { () -> Void in
//
//                                        self.wlhuman.standaction()
//                                })
//
//         }
//
//    }
//    func     rightaction(gesture:UILongPressGestureRecognizer)
//    {
//        let   position=wlhuman.position
//        if    position.x<(view?.frame.size.width)!-wlhuman.size.width/2.0-10
//        {
//
//            wlhuman.removeAllActions()
//            wlhuman.runAction(SKAction.group([                        SKAction.moveToX(position.x+movespeed, duration:2/10),SKAction.animateWithTextures(wlhuman.turnrightframe , timePerFrame:2/30)
//
//
//
//                ]), completion: { () -> Void in
//
//                    self.wlhuman.standaction()
//            })




//    }



