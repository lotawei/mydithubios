//
//  WLHuman.swift
//  iobb
//
//  Created by lotawei on 16/4/7.
//  Copyright © 2016年 wl. All rights reserved.
//

import UIKit
import SpriteKit
enum  ActionState:Int {
    case stand=1,left,right,jump;
}

@objc  protocol  WlHumanprotocol
{
    
    


    func   humanwilljump()->CGPoint
    func   humanwillleft()->CGPoint
    func   humanwillright()->CGPoint
}



class WLHuman: SKSpriteNode {
    
    static let   jumpvalue:CGFloat=40
    static  let  contactmask=00000001
    
    
    
    var   actionstate:ActionState=ActionState.stand
    var    standatlas=SKTextureAtlas(named: "stand")
    var    turnrightatlas=SKTextureAtlas(named: "turnright")
    var    turnleftatlas=SKTextureAtlas(named: "turnleft")
     var   jumpatlas=SKTextureAtlas(named: "jump")
    
    var   standframe=[SKTexture]()
    var   turnrightframe=[SKTexture]()
    var   turnleftframe=[SKTexture]()
    var  jumpframe=[SKTexture]()
    var    delegate:WlHumanprotocol?
    
    init()
    {
        let    texture=standatlas.textureNamed("stand_01.png")
        
        let  size=CGSizeMake(40, 40)
        print("original"+"\(size)")
        super.init(texture: texture, color:SKColor.redColor(), size: size)
        settextureframe("stand_", atlas: standatlas)
        settextureframe("left_", atlas: turnleftatlas)
        settextureframe("right_", atlas: turnrightatlas)
          settextureframe("jump_", atlas: jumpatlas)
        
    }
    func   settextureframe(name:String,atlas:SKTextureAtlas)
    {
        let   cout  = atlas.textureNames.count
        if   name=="stand_"
        {
            
            for   i  in  1...cout
            {
                let   aname=String(format: "stand_%.2d", i)
                let   atexture=standatlas.textureNamed(aname)
                if   atexture.isKindOfClass(SKTexture)
                {
                    standframe.append(atexture)
                }
                
                
            }
            
            
        }
        else if  name=="left_"
        {
            for  i in 1...cout
            {
                
                let   aname=String(format: "left_%.2d", i)
                let   atexture=turnleftatlas.textureNamed(aname)
                if   atexture.isKindOfClass(SKTexture)
                {
                    turnleftframe.append(atexture)
                }
            }
            
            
        }
        else  if  name=="right_"
        {
            for  i in 1...cout
            {
                
                let   aname=String(format: "right_%.2d", i)
                let   atexture=turnrightatlas.textureNamed(aname)
                if   atexture.isKindOfClass(SKTexture)
                {
                    turnrightframe.append(atexture)
                }
            }
            
        }
        else  if  name=="jump_"
        {
            for  i in 1...cout
            {
                
                let   aname=String(format: "jump_%.2d", i)
                let   atexture=jumpatlas.textureNamed(aname)
                if   atexture.isKindOfClass(SKTexture)
                {
                    jumpframe.append(atexture)
                }
            }
        }
        
        
    }
    
    
    
    
    func   standaction()
    {
        self.removeAllActions()
        self.actionstate=ActionState.stand
        self.runAction(SKAction.repeatActionForever(SKAction.animateWithTextures(standframe, timePerFrame: 0.3)))
        
    }
        //向右行走的动画
        func   turnrightaction()
        {
    
            self.removeAllActions()
            self.actionstate=ActionState.right
            self.delegate?.humanwillright()
            self.runAction(SKAction.sequence([SKAction.group([SKAction.animateWithTextures(self.turnrightframe , timePerFrame:2/30)
                
                
                ]),SKAction.repeatActionForever(SKAction.animateWithTextures(standframe, timePerFrame: 0.3))]))
            
    
    
        }
        //zuo行走的动画
        func   turnleftaction()
        {
    
            self.removeAllActions()
            self.actionstate=ActionState.left
           self.delegate!.humanwillleft()
            self.runAction(SKAction.sequence([SKAction.group([SKAction.animateWithTextures(self.turnleftframe , timePerFrame:2/30)
                
                
                ]),SKAction.repeatActionForever(SKAction.animateWithTextures(standframe, timePerFrame: 0.3))]))
            
            
    
        }
    //  跳跃的动画
    func   jumpaction()
    {
    
    self.removeAllActions()
    self.actionstate=ActionState.jump
   
     let   newhigh = self.delegate!.humanwilljump()
      
        
        
        
        
//                                        self.runAction(SKAction.group([                        SKAction.moveToY(newhigh, duration:2/10),SKAction.animateWithTextures(self.jumpframe , timePerFrame:2/30),
//                                           SKAction.moveToY(originalhigh, duration:2/10)
//        
//        
//                                            ]), completion: { () -> Void in
//        
//                                               
//                                                self.standaction()
//                                        })
        self.runAction(SKAction.sequence([SKAction.group([                        SKAction.moveToY(newhigh.y, duration:2/10),SKAction.animateWithTextures(self.jumpframe , timePerFrame:2/30)
        
        
                                                   ]),SKAction.repeatActionForever(SKAction.animateWithTextures(standframe, timePerFrame: 0.3))]))
     

    
    }
    
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
}
