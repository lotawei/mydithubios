//
//  WLSkview.swift
//  firstscene
//
//  Created by lw on 16/4/12.
//  Copyright © 2016年 lw. All rights reserved.
//

import UIKit
import  SpriteKit
//protocol    GuesTurePro
//{
//    func    changemyplayer(direction:UISwipeGestureRecognizerDirection)
//}

class WLSkview: SKView {

    var    aswip:UISwipeGestureRecognizer!
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
     override init(frame: CGRect) {
        super.init(frame: frame)
         aswip=UISwipeGestureRecognizer(target: self, action: "curswipgesture:")
    }
    func  curswipgesture(gesture:UISwipeGestureRecognizer)
    {
        self.delegate?.changemyplayer(gesture.direction)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override func drawRect(rect: CGRect) {
      
    }


}
