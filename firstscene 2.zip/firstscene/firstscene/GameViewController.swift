//
//  GameViewController.swift
//  firstscene
//
//  Created by lw on 16/4/12.
//  Copyright (c) 2016年 lw. All rights reserved.
//

import UIKit
import SpriteKit

class GameViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
            // Configure the view.
            let skView = self.view as! SKView
            skView.showsFPS = true
            skView.showsNodeCount = true
           
            /* Sprite Kit applies additional optimizations to improve rendering performance */
            skView.ignoresSiblingOrder = true
            
            /* Set the scale mode to scale to fit the window */
           
            
            skView.presentScene(PlayScene ())
     
    }

    override func shouldAutorotate() -> Bool {
        return true
    }

   

    override func prefersStatusBarHidden() -> Bool {
        return true
    }
}
