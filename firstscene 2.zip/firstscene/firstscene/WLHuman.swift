//
//  WLHuman.swift
//  iobb
//
//  Created by lotawei on 16/4/7.
//  Copyright © 2016年 wl. All rights reserved.
//

import UIKit
import SpriteKit
enum  ActionState:Int {
    case stand=1,left,right;
}

@objc  protocol  WlHumanprotocol
{
    
    
    optional
    func humanwillmoveright(human:WLHuman)
    func  humanwillmoveleft(human:WLHuman)
    
    
}



class WLHuman: SKSpriteNode {
    
    static let   jumpvalue:CGFloat=40
    var   actionstate:ActionState=ActionState.stand
    var    standatlas=SKTextureAtlas(named: "stand")
    var    turnrightatlas=SKTextureAtlas(named: "turnright")
    var    turnleftatlas=SKTextureAtlas(named: "turnleft")
    
    
    var   standframe=[SKTexture]()
    var   turnrightframe=[SKTexture]()
    var   turnleftframe=[SKTexture]()
    
    
    var    delegate:WlHumanprotocol?
    
    init()
    {
        let    texture=standatlas.textureNamed("stand_01.png")
        
        let  size=CGSizeMake(texture.size().width/4.0, texture.size().height/4.0)
        
        super.init(texture: texture, color:SKColor.redColor(), size: size)
        settextureframe("stand_", atlas: standatlas)
        settextureframe("left_", atlas: turnleftatlas)
        settextureframe("right_", atlas: turnrightatlas)
        
        
    }
    func   settextureframe(name:String,atlas:SKTextureAtlas)
    {
        let   cout  = atlas.textureNames.count
        if   name=="stand_"
        {
            
            for   i  in  1...cout
            {
                let   aname=String(format: "stand_%.2d", i)
                let   atexture=standatlas.textureNamed(aname)
                if   atexture.isKindOfClass(SKTexture)
                {
                    standframe.append(atexture)
                }
                
                
            }
            
            
        }
        else if  name=="left_"
        {
            for  i in 1...cout
            {
                
                let   aname=String(format: "left_%.2d", i)
                let   atexture=turnleftatlas.textureNamed(aname)
                if   atexture.isKindOfClass(SKTexture)
                {
                    turnleftframe.append(atexture)
                }
            }
            
            
        }
        else  if  name=="right_"
        {
            for  i in 1...cout
            {
                
                let   aname=String(format: "right_%.2d", i)
                let   atexture=turnrightatlas.textureNamed(aname)
                if   atexture.isKindOfClass(SKTexture)
                {
                    turnrightframe.append(atexture)
                }
            }
            
        }
        
        
    }
    
    
    
    
    func   standaction()
    {
        self.removeAllActions()
        self.actionstate=ActionState.stand
        self.runAction(SKAction.repeatActionForever(SKAction.animateWithTextures(standframe, timePerFrame: 0.3)))
        
    }
        //向右行走的动画
        func   turnrightaction()
        {
    
            self.removeAllActions()
            self.actionstate=ActionState.right
            self.runAction(SKAction.repeatActionForever(SKAction.animateWithTextures(turnrightframe, timePerFrame: 0.3)))
            delegate?.humanwillmoveright!(self)
    
    
        }
        //zuo行走的动画
        func   turnleftaction()
        {
    
            self.removeAllActions()
            self.actionstate=ActionState.left
            self.runAction(SKAction.repeatActionForever(SKAction.animateWithTextures(turnleftframe, timePerFrame: 0.3)))
           delegate?.humanwillmoveleft(self)
    
        }
    //
    
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
}
