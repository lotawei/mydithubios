//
//  GameScene.swift
//  firstscene
//
//  Created by lw on 16/4/12.
//  Copyright (c) 2016年 lw. All rights reserved.
//

import SpriteKit

//
//  PlayScene.swift
//  iobb
//
//  Created by lotawei on 16/4/4.
//  Copyright © 2016年 wl. All rights reserved.
//

import UIKit
import SpriteKit


class PlayScene: SKScene,UIGestureRecognizerDelegate,WlHumanprotocol {
    
    //默认一秒只处理一次手势0.6
    var   lasttimeclick:NSTimeInterval=0.0
   
    var   dt:NSTimeInterval=0.3
    var     gravityisup = false
    //跳跃手势
    var    jumpswip:UISwipeGestureRecognizer!
    //向左移动
       var    leftswip:UISwipeGestureRecognizer!
    //向右移动
       var    rightswip:UISwipeGestureRecognizer!
    //向下蹲
       var    downswip:UISwipeGestureRecognizer!
    var   iscreate=false
    //速度
    var   movespeed:CGFloat = 10
    //移动时长
    var   duration:NSTimeInterval  = 0.2
    

    var   backgroud:SKNode!
    var   padding:CGFloat=20
    //通过这个变量停止动画
    var    isstopanimation=true
    var    wlhuman:WLHuman!
    //地平线
    var    groundline:SKSpriteNode!
      var    endgroundline:SKSpriteNode!
    //第一个矮的方块
    
    var    barrier:SKSpriteNode!
    //第二个的方块
    
    var    midbarrier:SKSpriteNode!
    //弹簧
    var     spring:SKSpriteNode!
    //三个奖励星星的
    var     s1:SKSpriteNode!
    var     s2:SKSpriteNode!
    var     s3:SKSpriteNode!
    //重力改变装置
    var      gravityequip:SKSpriteNode!
    
    
    //传送门
    
    var     door:SKSpriteNode!
    
    var     shouldupsidepoints:[CGPoint] = [CGPoint]()
    
    override  func didMoveToView(view: SKView) {
        self.size=view.frame.size
        
        
        createcontent()
        
        
    }
    
    
    
    func   createcontent()
    {
        if  iscreate {
            
            return
        }
        
        //页面内容的设置
        backgroud=SKNode()
        
        backgroud.zPosition=0
        backgroud.name="backgroud"
        let   backsprite=SKSpriteNode(imageNamed: "backgroud")
        backsprite.name="backsprite"
        backsprite.anchorPoint=CGPointMake(0, 0)
        backsprite.zPosition=1
        backsprite.position=CGPointZero
        backgroud.addChild(backsprite)
        
        
        self.backgroundColor=UIColor.whiteColor()
        groundline=SKSpriteNode(imageNamed: "groudline")
        groundline.anchorPoint=CGPointMake(0.5, 0.5)
        groundline.zPosition=2
        groundline.position=CGPointMake(groundline.size.width/2.0, CGRectGetMidY(self.frame))
        backgroud.addChild(groundline)
        
        
        wlhuman=WLHuman()
        wlhuman.name="wlhuman"
        wlhuman.zPosition=7
        wlhuman.anchorPoint=CGPointMake(0.5, 0.5)
        wlhuman.position=CGPointMake(CGRectGetMidX(self.frame),groundline.position.y+wlhuman.size.height)
        print(wlhuman.size)
        wlhuman.standaction()
        self.addChild(wlhuman)
        
       
        barrier=SKSpriteNode(imageNamed: "smallbarrier")
        barrier.anchorPoint=CGPointMake(0.5, 1)
        barrier.zPosition=2
        
        barrier.position=CGPointMake(CGRectGetMaxX(groundline.frame)-padding*6,groundline.position.y+barrier.size.height)
        backgroud.addChild(barrier)
        
        
        midbarrier=SKSpriteNode(imageNamed: "midbarrier")
        midbarrier.anchorPoint=CGPointMake(0.5, 1)
        midbarrier.zPosition=2
        print(midbarrier.size)
        midbarrier.position=CGPointMake(barrier.position.x+barrier.size.width+padding,groundline.position.y+midbarrier.size.height)
        backgroud.addChild(midbarrier)
        
        
        spring = SKSpriteNode(imageNamed: "spring")
        spring.anchorPoint=CGPointMake(0.5, 1)
        spring.zPosition=2
     
        spring.position=CGPointMake(CGRectGetMaxX( groundline.frame)+spring.size.width/2.0,groundline.position.y)
        backgroud.addChild(spring)
        
        gravityequip = SKSpriteNode(imageNamed: "gravitychange")
        gravityequip.zPosition = 2
        gravityequip.anchorPoint = CGPointMake(0.5, 0.5)
        gravityequip.position = CGPointMake(CGRectGetMaxX(spring.frame) + gravityequip.size.width/2.0+1, spring.position.y - gravityequip.size.height/2.0+1)
        backgroud.addChild(gravityequip)
        
        
        
        s1 = SKSpriteNode(imageNamed: "star")
        s1.anchorPoint=CGPointMake(0.5, 1)
        s1.zPosition=2
     
        s1.position=CGPointMake(spring.position.x,spring.position.y+midbarrier.size.height+WLHuman.jumpvalue)
        backgroud.addChild(s1)
        s2 = SKSpriteNode(imageNamed: "star")
        s2.anchorPoint=CGPointMake(0.5, 1)
        s2.zPosition=2
    
        s2.position=CGPointMake(CGRectGetMaxX(spring.frame)+WLHuman.jumpvalue*3,spring.position.y+s2.size.height)
        backgroud.addChild(s2)
        s3 = SKSpriteNode(imageNamed: "star")
        s3.anchorPoint=CGPointMake(0.5, 1)
        s3.zPosition=2
        
        s3.position=CGPointMake(s2.position.x+s2.size.width+padding,spring.position.y+s2.size.height)
        backgroud.addChild(s3)
        
        
        door  = SKSpriteNode(imageNamed: "door")
      
       door.anchorPoint=CGPointMake(0.5, 1)
        door.zPosition=5
        
        door.position=CGPointMake(CGRectGetMaxX(s3.frame)+padding*2,groundline.position.y+door.size.height)
        backgroud.addChild(door)
        
        
        
        endgroundline  = SKSpriteNode(imageNamed: "groudline")
        
        endgroundline.anchorPoint=CGPointMake(0,0)
        endgroundline.zPosition=2
        
        endgroundline.position=CGPointMake(CGRectGetMaxX(gravityequip.frame)-2,groundline.position.y)
        backgroud.addChild(endgroundline)
         addChild(backgroud)
        
        
        jumpswip=UISwipeGestureRecognizer(target: self, action: "guestureaction:")
        
        jumpswip.direction=UISwipeGestureRecognizerDirection.Up
        
        self.view!.addGestureRecognizer(jumpswip)
        downswip=UISwipeGestureRecognizer(target: self, action: "guestureaction:")
        
        downswip.direction=UISwipeGestureRecognizerDirection.Down
        
        self.view!.addGestureRecognizer(downswip)
        leftswip=UISwipeGestureRecognizer(target: self, action: "guestureaction:")
        
        leftswip.direction=UISwipeGestureRecognizerDirection.Left

        self.view!.addGestureRecognizer(leftswip)
        rightswip=UISwipeGestureRecognizer(target: self, action: "guestureaction:")
        
        rightswip.direction=UISwipeGestureRecognizerDirection.Right
        
        self.view!.addGestureRecognizer(rightswip)
       
        //设置物理边界
        //初始化重力方向向下
        self.physicsWorld.gravity = CGVectorMake(0, -1)
        self.physicsWorld.speed   = 2
        
        
        self.physicsBody = SKPhysicsBody(edgeLoopFromRect: self.frame)
        
        wlhuman.createphysicsappear()
        
        print(groundline.size)
        groundline.physicsBody = SKPhysicsBody(rectangleOfSize: groundline.size)
        groundline.physicsBody?.dynamic=false
        spring.physicsBody = SKPhysicsBody(rectangleOfSize: spring.size)
        spring.physicsBody?.dynamic = false
        
        gravityequip.physicsBody = SKPhysicsBody(rectangleOfSize: gravityequip.size)
        gravityequip.physicsBody?.dynamic = false
        
        
        endgroundline.physicsBody = SKPhysicsBody(rectangleOfSize: endgroundline.size)
        endgroundline.physicsBody?.dynamic = false
        
        
        barrier.physicsBody = SKPhysicsBody(rectangleOfSize: barrier.size)
        barrier.physicsBody?.dynamic = false
        
        
        
        
       
        iscreate=true
        
    }
    
    //实现即将跳跃的代理因为这里不像左右移动 这里我们的任务他的位置实际是要发生变化的
    func  humanwilljump() -> CGPoint {
        
        if    gravityisup {
        
        
         return  CGPointMake(wlhuman.position.x,  wlhuman.position.y-WLHuman.jumpvalue)
        }
        
         return  CGPointMake(wlhuman.position.x,  wlhuman.position.y+WLHuman.jumpvalue)
    }
//    func  humanwilldown(huaman: WLHuman) {
//        wlhuman.delegate=self
//        
//        print("去实现下蹲的动画")
//    }
    func   humanwillleft()->CGPoint {
      
        return   wlhuman.position
        
    }
    func   humanwillright()->CGPoint {
          return   wlhuman.position
    }
  override  func  update(currentTime: NSTimeInterval) {
        if   wlhuman.position.x != CGRectGetMidX(self.frame)
        {
            wlhuman.position.x = CGRectGetMidX(self.frame)
          return
     }
      print(backgroud.position.x)
      print("\(CGRectGetMaxX(spring.frame))")
      print("\(groundline.size.width)")
    
            
    
   }
    
    
    
    //手势轻扫的动作
    func  guestureaction(gesture:UISwipeGestureRecognizer)
    {
    
        let    nsdate=NSDate()
        let   currentime = nsdate.timeIntervalSince1970

        if    lasttimeclick==0
        {
            
            dealwithgesture(gesture)
            lasttimeclick=currentime
            

        }
        else
        {
            
            dt = currentime - lasttimeclick
            
            if  dt < 0.6
            {
                
                return
            }
           dealwithgesture(gesture)
           lasttimeclick=currentime
            
        }
        
    }
    func    dealwithgesture(gesture:UISwipeGestureRecognizer)
    {
        let    atype=gesture.direction
        
        
        if   atype==UISwipeGestureRecognizerDirection.Up
        {
            
            wlhuman.delegate=self
            wlhuman.jumpaction()
            
            
        }
        else   if atype==UISwipeGestureRecognizerDirection.Down
            
        {
            print("move down")
            
        }
        else   if atype==UISwipeGestureRecognizerDirection.Right
            
        {
            
            wlhuman.delegate=self
            
            wlhuman.turnrightaction()
            allcontentmoveleft()
            
        }
        else   if atype==UISwipeGestureRecognizerDirection.Left
            
        {
            wlhuman.delegate=self
            wlhuman.turnleftaction()
            allcontentmoveright()
        }
        

    }
    
    
    
    func    allcontentmoveleft()
    {
        
     
        if  backgroud.position.x <= -1000 {
              return
        }
        backgroud.runAction(SKAction.moveToX(backgroud.position.x-50, duration: duration))
       
     
    }
    func    allcontentmoveright()
    {
        
      if   backgroud.position.x >= 0
        {
            return
        }
        
        backgroud.runAction(SKAction.moveToX(backgroud.position.x+50, duration: duration))
        print("backright"+"\(backgroud.position.x)")
        

    }
    override   func didEvaluateActions() {
        
        
    }
    
    

    
}







