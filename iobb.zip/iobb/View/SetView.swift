//
//  SetView.swift
//  iobb
//
//  Created by lotawei on 16/4/4.
//  Copyright © 2016年 wl. All rights reserved.
//
//设置界面自定义
import UIKit

//定义协议  希望以后可以复用这个xib
@objc  protocol    SetViewProtocol
{
    
    func    setwillDidBack()
    
    //这里的保存 其实就应该穿一个参数 ，用于让场景 保存当前的设置
    optional  func  setwillsave()
    
    
}



class SetView: UIView {
    let  stateon="switch_on"

    let  stateoff="switch_off"
    
    var   state=true
    
    @IBOutlet weak var btneffectsound: UIButton!
    @IBAction func btneffectchange(sender: AnyObject) {
        
        if  state
        {
            state=false
            btneffectsound.setImage(  UIImage(named:self.stateoff), forState: UIControlState.Normal)
        }
        else
            {
                
                state=true
                btneffectsound.setImage(  UIImage(named:self.stateon), forState: UIControlState.Normal)
        }
        
        
    }
    var   delegate:SetViewProtocol?
    @IBAction func btnback(sender: AnyObject) {
        
        
        
        self.delegate?.setwillDidBack()
        self.removeFromSuperview()
        
        
    }
    
    
    
    override func drawRect(rect: CGRect) {
        
        btneffectsound.setImage(  UIImage(named:self.stateoff), forState: UIControlState.Normal)
        state=true
    }
   

}
