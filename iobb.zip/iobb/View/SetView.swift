//
//  SetView.swift
//  iobb
//
//  Created by lotawei on 16/4/4.
//  Copyright © 2016年 wl. All rights reserved.
//
//设置界面自定义
import UIKit

//定义协议 
@objc  protocol    SetViewProtocol
{
    
    func    setwillDidBack()
    
    //这里的保存 其实就应该穿一个参数 ，用于让场景 保存当前的设置
    optional  func  setwillsave()
    
    
}



class SetView: UIView {
    
    var   effectstate:Bool!
    var   soundstate:Bool!
    var   delegate:SetViewProtocol?
  
    @IBOutlet weak var switcheffect: UISwitch!

    @IBOutlet weak var switchsounds: UISwitch!
    
    @IBAction func seteffect(sender: AnyObject) {
        effectstate=switcheffect.on
    }
    
    @IBAction func setsounds(sender: AnyObject) {
        soundstate=switchsounds.on
    }
    
    
  
    
    @IBAction func Saveset(sender: AnyObject) {
        
        //保存到设置文件
        let    defaults=NSUserDefaults.standardUserDefaults()
       defaults.setBool(effectstate, forKey: "effectstate")
       defaults.setBool(soundstate, forKey: "soundstate")
       defaults.synchronize()
        
    }
   
 
    
 
    
    @IBAction func btnback(sender: AnyObject) {
        
        
        
        self.delegate?.setwillDidBack()
        self.removeFromSuperview()
        
        
    }
    
    
    
    override func drawRect(rect: CGRect) {
        
        let   defaults=NSUserDefaults.standardUserDefaults()
        var     isfirst = defaults.objectForKey("isfirst")
        if   (isfirst == nil)
        {
            isfirst=true
            print("是第一次唉")
            defaults.setBool(true, forKey: "isfirst")
            effectstate=true
            soundstate=true
            switcheffect.setOn(true, animated: true)
            switchsounds.setOn(true, animated: true)
            defaults.setBool(true, forKey: "effectstate")
            defaults.setBool(true, forKey: "soundstate")
            defaults.synchronize()

            
        }
        else
        {
            isfirst=false
            print("不是第一次哟")
            //保存到设置文件
            let    defaults=NSUserDefaults.standardUserDefaults()
            effectstate=defaults.objectForKey("effectstate")as! Bool
            soundstate=defaults.objectForKey("soundstate") as! Bool
            switcheffect.setOn(effectstate, animated: true)
            switchsounds.setOn(soundstate, animated: true)
            
            
            
            
            
        }
       
    }
   

}
