//
//  SetView.swift
//  iobb
//
//  Created by lotawei on 16/4/4.
//  Copyright © 2016年 wl. All rights reserved.
//
//设置界面自定义
import UIKit

//定义协议  希望以后可以复用这个xib
@objc  protocol    SetViewProtocol
{
    
    func    setwillDidBack()
    
    //这里的保存 其实就应该穿一个参数 ，用于让场景 保存当前的设置
    optional  func  setwillsave()
    
    
}



class SetView: UIView {
    
    var   effectstate=true
    var   soundstate=true
    @IBAction func soundstate(sender: AnyObject) {
        
        
        
    }
    
    @IBAction func Saveset(sender: AnyObject) {
        
        //保存到设置文件
        
        
    }
    @IBAction func effectsoundstate(sender: AnyObject) {
//        let   asender=sender as! UISwitch
//        if   asender.on
//        {
//            asender.setOn(false, animated: true)
//            
//        }else{
//            asender.setOn(true, animated: true)
//        }
        
    }
    var   state=true
    
    @IBOutlet weak var btneffectsound: UIButton!
       var   delegate:SetViewProtocol?
    @IBAction func btnback(sender: AnyObject) {
        
        
        
        self.delegate?.setwillDidBack()
        self.removeFromSuperview()
        
        
    }
    
    
    
    override func drawRect(rect: CGRect) {
        
       
    }
   

}
