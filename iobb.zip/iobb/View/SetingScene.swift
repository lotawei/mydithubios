//
//  SetingScene.swift
//  iobb
//
//  Created by lotawei on 16/4/4.
//  Copyright © 2016年 wl. All rights reserved.
//



       //游戏设置的场景
import UIKit
import  SpriteKit
class SetingScene: SKScene,SetViewProtocol {
    var    background=SKNode()
    var   iscreate=false
    var    backsprite:SKSpriteNode!
    override func  didMoveToView(view: SKView) {
        size=view.frame.size
        createcontent()
    }
    func  createcontent()
    {
        if  iscreate
        {
            return
        }
        background.alpha=1
        //设置背景sprite
        backsprite=SKSpriteNode(imageNamed: "Mainback")
        backsprite.zPosition=2
            backsprite.anchorPoint=CGPointMake(0.5, 1)
        backsprite.position=CGPointMake(CGRectGetMidX((view?.frame)!),CGRectGetMaxY((view?.frame)!))
        background.addChild(backsprite)
        //添加自定义设置的view
        let   setvie=NSBundle.mainBundle().loadNibNamed("SetView", owner: self, options: nil).first as! SetView
        setvie.delegate=self
        let   maxwidth=view?.bounds.size.width
        var   xpadding=CGFloat(0.0)
        let   maxheight=view?.bounds.size.height
        var  ypadding=CGFloat( 0.0)
        
        xpadding=(maxwidth!-setvie.bounds.size.width)/2.0
        ypadding=(maxheight!-setvie.bounds.size.height)/2.0
        setvie.frame=CGRectMake(xpadding, ypadding, maxwidth!, maxheight!)
        view?.addSubview(setvie)
        addChild(background)
    }

    //回到首页
    func  setwillDidBack() {
        
        self.view?.presentScene(GameMainScene(), transition: SKTransition.crossFadeWithDuration(2))
        
    }
    
    
    
}
