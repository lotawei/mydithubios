//
//  HelpScene.swift
//  iobb
//
//  Created by lotawei on 16/4/4.
//  Copyright © 2016年 wl. All rights reserved.
//


     //帮助的场景
import UIKit
import  SpriteKit
class HelpScene: SKScene {

    
    
    
    
}
