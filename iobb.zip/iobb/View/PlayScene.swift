//
//  PlayScene.swift
//  iobb
//
//  Created by lotawei on 16/4/4.
//  Copyright © 2016年 wl. All rights reserved.
//

import UIKit
import SpriteKit
class PlayScene: SKScene ,WlHumanprotocol{
    var   iscreate=false
    var   lasttime:NSTimeInterval=0
    var   dt:NSTimeInterval=0
    var   backgroud:SKNode!
 
    var   movepeed=15.0
   
    var    wlhuman:WLHuman!
    override  func didMoveToView(view: SKView) {
            self.size=view.frame.size
        
        
            createcontent()
        
             
    }
    
    
    
    func   createcontent()
    {
        
      backgroud=SKNode()
        backgroud.name="backgroud"
      let   backsprite=SKSpriteNode(imageNamed: "backgroud")
        backsprite.name="backsprite"
       backsprite.anchorPoint=CGPointMake(0, 0)
        backsprite.zPosition=1
       backsprite.position=CGPointZero
       backgroud.addChild(backsprite)
    
      
      self.backgroundColor=UIColor.whiteColor()
        if  iscreate {
            
            return
        }
        wlhuman=WLHuman()
        
        
        wlhuman.name="wlhuman"
       
        wlhuman.anchorPoint=CGPointMake(0.5, 1)
        wlhuman.position=CGPointMake(wlhuman.frame.size.width/2.0, wlhuman.frame.size.height)
        
        wlhuman.standaction()
        
        backgroud.addChild(wlhuman)

        
        
        
        
        
        
        addChild(backgroud)
        
    }
    override   func update(currentTime: NSTimeInterval) {
        if  dt<=1
        {
            dt=currentTime-lasttime
            lasttime=currentTime
            
        
            
        }
        else
        {
          
            let    backgroud=childNodeWithName("backgroud")
            let   sp=backgroud?.childNodeWithName("backsprite")
            
            

        }
        
        
        
    }
    override  func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
            let   position=wlhuman.position
        
            for   touch  in  touches
            {
                let   clickposition =  touch.locationInView(view)
                if  clickposition.x>position.x
                {
                  wlhuman.delegate=self
                    let   xpad = Double( clickposition.x-position.x)
                    let  duration=xpad/movepeed
                    wlhuman.removeAllActions()
                    wlhuman.runAction(SKAction.group([SKAction.animateWithTextures(wlhuman.turnrightframe, timePerFrame:duration/30),
                        SKAction.moveToX(clickposition.x, duration: duration/10)
                        ]), completion: { () -> Void in
                       self.wlhuman.standaction()
                    })
                    
                }
                if  clickposition.x<position.x-wlhuman.frame.size.width/2.0
                {
                     wlhuman.delegate=self
                    
                    let   xpad = Double( position.x-clickposition.x)
                    let  duration=xpad/movepeed
                    wlhuman.removeAllActions()
                    wlhuman.runAction(SKAction.group([                        SKAction.moveToX(clickposition.x, duration:duration/10),SKAction.animateWithTextures(wlhuman.turnleftframe , timePerFrame:duration/30)

                        
                        
                        ]), completion: { () -> Void in
                            self.wlhuman.standaction()
                    })
                    
                }
            }
        
        
        
    }
    
    
    func  humanwillmoveright(human:WLHuman) {
        
    }
    func   humanwillmoveleft(human:WLHuman) {
        
    }
    
    
    
  
    
    
    
    
    
    
    
    
    
        
    

}
