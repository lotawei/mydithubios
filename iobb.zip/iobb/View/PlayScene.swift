//
//  GameScene.swift
//  firstscene
//
//  Created by lw on 16/4/12.
//  Copyright (c) 2016年 lw. All rights reserved.
//

import SpriteKit


import UIKit
import SpriteKit

//  函数  从  update.didSimulatePhysics.didEvaluateActions 每帧顺序执行
class PlayScene: SKScene,UIGestureRecognizerDelegate,WlHumanprotocol , OperateProtocol ,SKPhysicsContactDelegate {
    
    //默认只处理一次手势0.6
    var   lasttimeclick:NSTimeInterval=0.0
   
    var   dt:NSTimeInterval=0.3
    //星星数量
    var   starcount = 4
    
    //定义两个变量 记录开始玩家距离 重力改变装置的结束的距离
    //由于每一帧都会发消息，希望不要在经过 我的重力改变装置一直给wlhuman发消息
    var   lastposttime = 0.0
    var   dtp:NSTimeInterval  =  2
    var   alllength:CGFloat = 0.0
    var   adstartpad:CGFloat = 0.0
     var   adendpad:CGFloat = 0.0
    //左移动
    var    rightbtn:BtnOperate!
    //right
    var    leftbtn:BtnOperate!
    
    var     aquene:dispatch_queue_t!
    //跳跃手势
    var    jumpswip:UISwipeGestureRecognizer!
      //向下蹲
    var    downswip:UISwipeGestureRecognizer!
    var   iscreate=false
    //速度
    var   movespeed:CGFloat =  50
    //移动时长
    var   duration:NSTimeInterval  = 0.4
    

    var   backgroud:SKNode!
    var   padding:CGFloat=20
    //通过这个变量停止动画
    var    isstopanimation=true
    var    wlhuman:WLHuman!
    //地平线
    var    groundline:SKSpriteNode!
      var    endgroundline:SKSpriteNode!
    //第一个矮的方块
    
    var    barrier:WLBarrierNode!
    //第二个的方块
    
    var    midbarrier:WLBarrierNode!
    //弹簧
    var     spring:WLSpringNode!
    //三个奖励星星的
    var     s1:WLStarNode!
    var     s2:WLStarNode!
    var     s3:WLStarNode!
     var     s4:WLStarNode!
    //重力改变装置
    var      gravityequip:WLGravityNode!
    var      ask:SKEmitterNode!
    
    //传送门
    
    var     door:WLDoorNode!
    
    
    override  func didMoveToView(view: SKView) {
        self.size=view.frame.size
        
        
        createcontent()
        
        
    }
    
    
    
    func   createcontent()
    {
        if  iscreate {
            
            return
        }
        
        //页面内容的设置
        backgroud=SKNode()
        
        backgroud.zPosition=0
        backgroud.name="backgroud"
        let   backsprite=SKSpriteNode(imageNamed: "backgroud")
        backsprite.name="backsprite"
        backsprite.anchorPoint=CGPointMake(0, 0)
        backsprite.zPosition=1
        backsprite.position=CGPointZero
        backgroud.addChild(backsprite)
        
        
        self.backgroundColor=UIColor.whiteColor()
        groundline=SKSpriteNode(imageNamed: "groudline")
        groundline.anchorPoint=CGPointMake(0.5, 0.5)
        groundline.zPosition=2
        groundline.position=CGPointMake(groundline.size.width/2.0, CGRectGetMidY(self.frame))
        backgroud.addChild(groundline)
        
        
        leftbtn=BtnOperate.init(frame: CGRectMake(20,self.frame.size.height-50, 54, 26),type:OprerateType.left)
        leftbtn.alpha=0.1
        leftbtn.setBackgroundImage(UIImage(named: "btnleft"), forState: .Normal)
        leftbtn.delegate=self
        
        
        rightbtn=BtnOperate.init(frame: CGRectMake(94
            ,self.frame.size.height-50,54,26) ,type:OprerateType.right)
        rightbtn.setBackgroundImage(UIImage(named: "btnright"), forState: .Normal)
        rightbtn.alpha=0.1
        rightbtn.delegate=self

        view?.addSubview(rightbtn)
        view?.addSubview(leftbtn)
        
        
        wlhuman=WLHuman()
        wlhuman.name="wlhuman"
        wlhuman.zPosition=7
        wlhuman.anchorPoint=CGPointMake(0.5, 0.5)
        wlhuman.position=CGPointMake(CGRectGetMidX(self.frame),groundline.position.y+wlhuman.size.height)
        wlhuman.maxh = self.frame.height
        wlhuman.standaction()
        self.addChild(wlhuman)
        
       
        barrier=WLBarrierNode(type: BarrierType.Small)
        barrier.anchorPoint=CGPointMake(0.5, 1)
        barrier.zPosition=2
        
        barrier.position=CGPointMake(CGRectGetMaxX(groundline.frame)-padding*6,groundline.position.y+barrier.size.height)
        backgroud.addChild(barrier)
        
        
        midbarrier=WLBarrierNode(type: BarrierType.Mid)
        midbarrier.anchorPoint=CGPointMake(0.5, 1)
        midbarrier.zPosition=2
        
        midbarrier.position=CGPointMake(barrier.position.x+barrier.size.width+padding,groundline.position.y+midbarrier.size.height)
        backgroud.addChild(midbarrier)
        
        
        spring = WLSpringNode()
        spring.anchorPoint=CGPointMake(0.5, 1)
        spring.zPosition=2
     
        spring.position=CGPointMake(CGRectGetMaxX( groundline.frame)+spring.size.width/2.0,groundline.position.y)
        backgroud.addChild(spring)
        
        gravityequip = WLGravityNode()
        gravityequip.zPosition = 2
       
        gravityequip.position = CGPointMake(CGRectGetMaxX(spring.frame) + gravityequip.size.width/2.0, groundline.position.y)
        backgroud.addChild(gravityequip)
      
        
        
        s1 = WLStarNode()
       
        s1.zPosition=2
     
        s1.position=CGPointMake(spring.position.x,spring.position.y+midbarrier.size.height+WLHuman.jumpvalue)
        backgroud.addChild(s1)
        
        s2 = WLStarNode()
      
        s2.zPosition=2
    
        s2.position=CGPointMake(CGRectGetMaxX(spring.frame)+WLHuman.jumpvalue*3,spring.position.y+s2.size.height)
        backgroud.addChild(s2)
       
        s3 = WLStarNode()
        
       
      
        s3.zPosition=2
        
        s3.position=CGPointMake(s2.position.x+s2.size.width+padding,spring.position.y+s2.size.height)
        backgroud.addChild(s3)
        s4 = WLStarNode()
        
        
        
        s4.zPosition=2
        
        s4.position=CGPointMake(s2.position.x+s2.size.width+padding,spring.position.y-s2.size.height)
        backgroud.addChild(s4)
        
        
        door  = WLDoorNode()
      
       
        door.zPosition=5
        
        door.position=CGPointMake(CGRectGetMaxX(s3.frame)+padding*2,groundline.position.y+door.size.height)
        backgroud.addChild(door)
        
        
        
        endgroundline  = SKSpriteNode(imageNamed: "groudline")
        
        endgroundline.anchorPoint=CGPointMake(0,1)
        endgroundline.zPosition=2
        
        endgroundline.position=CGPointMake(CGRectGetMaxX(gravityequip.frame)-2,groundline.position.y)
        backgroud.addChild(endgroundline)
         addChild(backgroud)
        
        
        jumpswip=UISwipeGestureRecognizer(target: self, action: "guestureaction:")
        
        jumpswip.direction=UISwipeGestureRecognizerDirection.Up
        downswip=UISwipeGestureRecognizer(target: self, action: "guestureaction:")
        
        downswip.direction=UISwipeGestureRecognizerDirection.Down
        view?.addGestureRecognizer(jumpswip)
         view?.addGestureRecognizer(downswip)
        //设置物理边界
        //初始化重力方向向下
        self.physicsWorld.gravity = CGVectorMake(0, -1)
        self.physicsWorld.speed   = 2
        
        
        self.physicsBody = SKPhysicsBody(edgeLoopFromRect: self.frame)
        
        
        
       
        groundline.physicsBody = SKPhysicsBody(rectangleOfSize: groundline.size)
        groundline.physicsBody?.dynamic=false
      
        
        
        
        endgroundline.physicsBody = SKPhysicsBody(rectangleOfSize: endgroundline.size)
        endgroundline.physicsBody?.dynamic = false
        
        
      

        
        
        self.physicsWorld.contactDelegate = self
        
        ask = NSKeyedUnarchiver.unarchiveObjectWithFile(NSBundle.mainBundle().pathForResource("spark", ofType: "sks")!) as! SKEmitterNode
        ask.zPosition = 3
        ask.alpha = 0
       
       
        ask.numParticlesToEmit = 8
        ask.particlePositionRange = CGVectorMake(spring.size.width, 2)
        ask.position = spring.position
        ask.advanceSimulationTime(2.0)
        backgroud.addChild(ask)
        adstartpad = groundline.size.width + spring.size.width - self.frame.size.width/2.0
        adendpad   = adstartpad + gravityequip.size.width
        alllength = groundline.size.width + gravityequip.size.width + endgroundline.size.width
        print("start:"+"\(adstartpad)")
        print("end"+"\(adendpad)")
        
        iscreate=true
        
    }
    func  setwlhuanmaxheight() -> CGFloat {
        return   self.frame.height
    }
    //实现即将跳跃的代理因为这里不像左右移动 这里我们的任务他的位置实际是要发生变化的
    func  humanwilljump() -> CGPoint {
        
        
        
         return  CGPointMake(wlhuman.position.x,  wlhuman.position.y)
    }

    func  MoveLeft() {
         isstopanimation = false
         aquene = dispatch_queue_create("left",nil)
         dispatch_async(aquene) { () -> Void in
            while(!self.isstopanimation){
                 NSThread.sleepForTimeInterval(0.2)
                self.allcontentmoveright()
                self.wlhuman.turnleftaction()
            }
               self.wlhuman.standaction()
        }

    }
    
    
    func  MoveRight() {
        isstopanimation = false
        
        aquene = dispatch_queue_create("left",nil)
        dispatch_async(aquene) { () -> Void in
            while(!self.isstopanimation){
                NSThread.sleepForTimeInterval(0.2)
                self.allcontentmoveleft()
                self.wlhuman.turnrightaction()
            }
            self.wlhuman.standaction()
            
        }
    }
   
    func StopMove() {
        self.isstopanimation = true
        
    }
  
    
    func    allcontentmoveleft()
    {
        if   backgroud.position.x <= -900
        {
            print(alllength - self.frame.width/2)
            return
        }
        
        backgroud.runAction(SKAction.moveToX(backgroud.position.x-movespeed, duration: duration))
        
      
   
    }
    func    allcontentmoveright()
    {
        
      if   backgroud.position.x >= -movespeed
        {
            return
        }
        
        backgroud.runAction(SKAction.moveToX(backgroud.position.x+movespeed, duration: duration))
      
       
       

    }
    
    func  guestureaction(gesture:UISwipeGestureRecognizer)
    {
        
        
        let     nsdate = NSDate()
        let    current=nsdate.timeIntervalSince1970
               if    lasttimeclick == 0
        {
             dealwithGesture(gesture)
            
       
            lasttimeclick = current
        }
        else
        {
            dt = current - lasttimeclick
           if   dt < 0.6
           {
            return
           }
          dealwithGesture(gesture)
          lasttimeclick = current
            
            
        }
        
        
    }
    func   dealwithGesture(gesture:UISwipeGestureRecognizer)
    {
        StopMove()
        let    atype=gesture.direction

        if   atype==UISwipeGestureRecognizerDirection.Up
        {
            
            if !wlhuman.gravityup
            {
            wlhuman.delegate=self
            
            wlhuman.jumpaction()
            wlhuman.actionstate = ActionState.stand
         
            }
            else
            {
                //下蹲
                wlhuman.squataction()
                wlhuman.actionstate = ActionState.stand
            }

            
            
        }
        else   if atype==UISwipeGestureRecognizerDirection.Down
            
        {
            if  wlhuman.gravityup
            {
                wlhuman.delegate=self
                
                wlhuman.jumpaction()
            }
            else
            {
                wlhuman.squataction()
            }
            
            
        }
    }
  
    
 
    
    
    
    override  func  update(currentTime: NSTimeInterval) {
        if  wlhuman.position.x != CGRectGetMidX(self.frame)
        {
            wlhuman.position.x = CGRectGetMidX(self.frame)
            
        }
        //根据计算可得到重力 与 偏移量的关系
        let    wlpy = wlhuman.position.y
        let    h   = wlhuman.size.height
        let    grl = groundline.position.y
        let     nsdate = NSDate()
        let    current=nsdate.timeIntervalSince1970
        if   lastposttime == 0
        {
            
        if  (backgroud.position.x < -(adstartpad) && backgroud.position.x > -(adendpad) ) && (wlpy>grl-h && wlpy < grl+h)
        {
           
            //每次往我这里跑
            jumpswip.enabled = false
            downswip.enabled = false
            wlhuman.gravityup = !wlhuman.gravityup
            let    gravityposition = gravityequip.position.y
            
            NSNotificationCenter.defaultCenter().postNotificationName("gravitychangenotification", object: gravityposition)
            wlhuman.delegate = self
            
            lastposttime = current
            
           return
        }
            jumpswip.enabled = true
             downswip.enabled = true
        }
        else
        {
            
         let     adt = current - lastposttime
            if   adt < dtp
            {
                
                return
            }
            if  (backgroud.position.x < -(adstartpad) && backgroud.position.x > -(adendpad) ) && (wlpy>grl-h && wlpy < grl+h)
            {
                
                //每次往我这里跑
                jumpswip.enabled = false
                downswip.enabled = false
                wlhuman.gravityup = !wlhuman.gravityup
                let    gravityposition = gravityequip.position.y
                
                NSNotificationCenter.defaultCenter().postNotificationName("gravitychangenotification", object: gravityposition)
                wlhuman.delegate = self
                lastposttime = current
                return
            }
            
            jumpswip.enabled = true
            downswip.enabled = true
            
        }
      
       
       
        
        
      
    }
    //使用代理知道当前的state发消息 让其 背景左右移动
    func    humanstateaction(state: ActionState) {
        
         if   state == ActionState.left
         {
            backgroud.runAction(SKAction.moveToX(backgroud.position.x + gravityequip.size.width, duration: 0.2))
       
            wlhuman.standaction()
            
         }
        else  if  state == ActionState.right
         {
             backgroud.runAction(SKAction.moveToX(backgroud.position.x - gravityequip.size.height, duration: 0.2))
          
             wlhuman.standaction()
            
        }
        else  if  state == ActionState.stand
         {
            
            
                
             
             
           
                wlhuman.standaction()
             
        }
//
        
        
    }
    
    
    
    
    override   func didEvaluateActions() {
        
        
    }
    
    //实现碰撞的代理
    func didBeginContact(contact: SKPhysicsContact) {
       let   bodya = contact.bodyA
        let    bodyb = contact.bodyB
        if    bodyb.categoryBitMask | bodya.categoryBitMask  == WLcategoryMask.contacstartmask | WLcategoryMask.contactplayermask
        {
               let   astar = bodyb.node as!  WLStarNode
            
                removestar(astar)
        }
        if    bodyb.categoryBitMask | bodya.categoryBitMask  == WLcategoryMask.contacdoortmask | WLcategoryMask.contactplayermask
        {
            if  !door.doorstate
            {
                door.opendooraction()
                
            }
            else
            {
                 if self.starcount > 0
                 {
                       //你还有星星没有吃完额
                    
                    
                 }
                 else
                 {
                      //游戏该结束啦
                    
                 }
            }
            
        }
        
        
        
        if    bodyb.categoryBitMask == WLcategoryMask.contacspringtmask        {
            
             ask.resetSimulation()
             ask.alpha = 1
              
        }
    }
   
   
    
    //让星星消失产生积分
    func    removestar(star:WLStarNode)
    {
        
        star.runAction(SKAction.fadeOutWithDuration(1))
        star.removeFromParent()
        self.starcount -= 1
    }
    
    override  func didSimulatePhysics() {
        
    
         if   !wlhuman.gravityup
         {
              self.physicsWorld.gravity = CGVectorMake(0, -1)
         }
        else
        {
              self.physicsWorld.gravity = CGVectorMake(0, 1)

        }
         if  wlhuman.position.y >=  self.frame.size.height - wlhuman.size.height/2.0
        {
            wlhuman.position.y  =   self.frame.size.height - wlhuman.size.height/2.0
        }
        if   wlhuman.position.y <=  wlhuman.size.height/2.0
        {
            wlhuman.position.y =  wlhuman.size.height/2.0
        }
        
        
        
        
    }
    
    

    
    

    
}







