//
//  PlayScene.swift
//  iobb
//
//  Created by lotawei on 16/4/4.
//  Copyright © 2016年 wl. All rights reserved.
//

import UIKit
import SpriteKit
class PlayScene: SKScene {
    var   iscreate=false
    
    
    override  func didMoveToView(view: SKView) {
            self.size=view.frame.size
        
        
            createcontent()
        
             
    }
    
    
    
    func   createcontent()
    {
        
      self.backgroundColor=UIColor.whiteColor()
        if  iscreate {
            
            return
        }
        let   wlhuman=WLHuman()
        
        
        wlhuman.name="wlhuman"
        wlhuman.anchorPoint=CGPointMake(0.5, 1)
        wlhuman.position=CGPointMake(CGRectGetMidX((view?.frame)!), CGRectGetMidY((view?.frame)!))
        wlhuman.standaction()
        addChild(wlhuman)
    }
    override  func   touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
         let   ahuman=self.childNodeWithName("wlhuman") as! WLHuman
         ahuman.turnleftaction()
         
        
        
        
    }
    
    
    
  
    
    
    
    
    
    
    
    
    
        
    

}
