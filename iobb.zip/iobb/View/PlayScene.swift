//
//  PlayScene.swift
//  iobb
//
//  Created by lotawei on 16/4/4.
//  Copyright © 2016年 wl. All rights reserved.
//

import UIKit
import SpriteKit
class PlayScene: SKScene {
    var   iscreate=false
    
    
    override  func didMoveToView(view: SKView) {
            self.size=view.frame.size
        
        
            createcontent()
        
             
    }
    
    
    
    func   createcontent()
    {
        
        self.backgroundColor=UIColor.redColor()
        if  iscreate {
            
            return
        }
        let  newpalyscene=GameMainScene()
        
        
        view?.presentScene(newpalyscene, transition:SKTransition.moveInWithDirection(.Right, duration: 2))
        
        
        
    }
    
    
    
    
    
        
    

}
