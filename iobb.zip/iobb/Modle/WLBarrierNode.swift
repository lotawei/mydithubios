//
//  BarrierNode.swift
//  firstscene
//
//  Created by lw on 16/4/20.
//  Copyright © 2016年 lw. All rights reserved.
//

import UIKit
import  SpriteKit
enum   BarrierType{
    case   Small , Mid
}
class WLBarrierNode: SKSpriteNode {
    
    var   type:BarrierType!
    
    
    init(type:BarrierType)
    {
        
        self.type = type
        if  self.type == .Small{
        let    texture=SKTexture(imageNamed: "smallbarrier")
        
        
        super.init(texture: texture, color:SKColor.redColor(), size: texture.size())
        self.anchorPoint = CGPointMake(0.5,1)
        createphysciappear()
            return
        }
        let    texture=SKTexture(imageNamed: "midbarrier")
        
        
        super.init(texture: texture, color:SKColor.redColor(), size: texture.size())
        self.anchorPoint = CGPointMake(0.5,1)
        createphysciappear()
        
        
    }
    func  createphysciappear()
    {
        self.physicsBody = SKPhysicsBody(rectangleOfSize: CGSizeMake(self.size.width, 1))
        self.physicsBody?.dynamic = false

      
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    

    
}
