//
//  WLDoorNode.swift
//  firstscene
//
//  Created by lw on 16/4/18.
//  Copyright © 2016年 lw. All rights reserved.
//

import UIKit
import SpriteKit
class WLDoorNode: SKSpriteNode {

    var     dooratlas=SKTextureAtlas(named: "opendoor")
     var   opendoorframe=[SKTexture]()
    var     doorstate = false
    init()
    {
        let    texture=SKTexture(imageNamed: "door")
        super.init(texture: texture, color:SKColor.redColor(), size: texture.size())
        self.anchorPoint = CGPointMake(0.5,1)
        let   cout  = dooratlas.textureNames.count
      
            for   i  in  1...cout
            {
                let   aname=String(format: "opendoor_%.2d", i)
                let   atexture=dooratlas.textureNamed(aname)
                
                if   atexture.isKindOfClass(SKTexture)
                {
                    opendoorframe.append(atexture)
                }
        }
        
          self.anchorPoint=CGPointMake(0.5, 1)

        createphysciappear()
        
        
    }
    func   opendooraction()
    {
        self.doorstate = true
        self.removeAllActions()
        self.runAction(SKAction.repeatActionForever(SKAction.animateWithTextures(opendoorframe, timePerFrame: 0.3)))
    }
    
    func  createphysciappear()
    {
        self.physicsBody = SKPhysicsBody(rectangleOfSize:CGSizeMake( self.size.width,2))
        self.physicsBody?.dynamic  = false
        
        self.physicsBody?.categoryBitMask = WLcategoryMask.contacdoortmask
        self.physicsBody?.contactTestBitMask = WLcategoryMask.contactplayermask
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
}
