//
//  SingleUniquenSet.swift
//  iobb
//
//  Created by lotawei on 16/4/7.
//  Copyright © 2016年 wl. All rights reserved.
//

import UIKit

class SingleUniquenSet {
    var     effectsoundstate:Bool=true;
    var     playersoundstate:Bool=true;
    class  var  Shareinstance:SingleUniquenSet{
       
        struct uniquen {
            static let instance = SingleUniquenSet()
        }
        return  uniquen.instance;
    }

}
