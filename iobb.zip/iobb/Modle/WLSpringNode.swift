//
//  SpringNode.swift
//  firstscene
//
//  Created by lw on 16/4/18.
//  Copyright © 2016年 lw. All rights reserved.
//


import   SpriteKit
class WLSpringNode: SKSpriteNode {
    //默认的反弹高度
    static let   defaultvalue:CGFloat=5
  
 
    
 
     init()
    {
        let    texture=SKTexture(imageNamed: "spring")
        
       
        
        super.init(texture: texture, color:SKColor.redColor(), size: CGSizeMake(texture.size().width - 10, 3))
        self.anchorPoint = CGPointMake(0.5,1)
        createphysciappear()
        
        
    }
    func  createphysciappear()
    {
        self.physicsBody = SKPhysicsBody(rectangleOfSize: self.size)
        self.physicsBody?.dynamic  = false
        self.physicsBody?.restitution = 1.0
        self.physicsBody?.categoryBitMask = WLcategoryMask.contacspringtmask
        self.physicsBody?.contactTestBitMask = WLcategoryMask.contactplayermask
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
