//
//  WLHuman.swift
//  iobb
//
//  Created by lotawei on 16/4/7.
//  Copyright © 2016年 wl. All rights reserved.
//

import UIKit
import SpriteKit
enum  ActionState:Int {
    case wink=1,run ,left,right;
}


class WLHuman: SKSpriteNode {
    var   actionstate:ActionState=ActionState.wink

    var   eyetextframe=[SKTexture]()
    init()
    {
//        let    texture=eyeatlas.textureNamed("ibb_eye_01.png")
        let    texture=SKTexture(imageNamed: "ibb_eye_01.png")
        let  size=texture.size()
        super.init(texture: texture, color: SKColor.whiteColor(), size: size)
     
        let   cout=4
        for   i in 1...cout
        {
            let  aname=String(format: "ibb_eye_%.2d", i)
            let  atextrue=SKTexture(imageNamed:aname)
            
            
            
            eyetextframe.append(atextrue)
        }
        
    }
    func   winkaction()
    {
        self.actionstate=ActionState.wink
        self.runAction(SKAction.repeatActionForever(SKAction.animateWithTextures(eyetextframe, timePerFrame: 0.5)))
    }
    
    
    
    
    
    
    
    
    
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
   
    
    
    
    

}
