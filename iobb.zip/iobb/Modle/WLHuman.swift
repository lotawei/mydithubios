//
//  WLHuman.swift
//  iobb
//
//  Created by lotawei on 16/4/7.
//  Copyright © 2016年 wl. All rights reserved.
//

import UIKit
import SpriteKit
enum  ActionState:Int {
    case stand=1,left,right,jump,squat;
}

  protocol  WlHumanprotocol
{
    
    
    
    //返回一个坐标是用于wlhuman回调
    func   humanwilljump()->CGPoint
    //为了让让主界面 知道角色是向左还是向右
    
   func   humanstateaction(state:ActionState)
    
    
    
}



class WLHuman: SKSpriteNode {
    
    static let   jumpvalue:CGFloat=50
    static  let  perduration = 0.3
    
    //获取屏幕的最大高度
    var    maxh :CGFloat = 0
    var    gravityup  =  false
    
    var   actionstate:ActionState=ActionState.stand
    var    standatlas=SKTextureAtlas(named: "stand")
    var    turnrightatlas=SKTextureAtlas(named: "turnright")
    var    turnleftatlas=SKTextureAtlas(named: "turnleft")
    var   jumpatlas=SKTextureAtlas(named: "jump")
    var    standdownatlas=SKTextureAtlas(named: "standdown")
    var    turnrightdatlas=SKTextureAtlas(named: "turnrightd")
    var    turnleftdatlas=SKTextureAtlas(named: "turnleftd")
    var   jumpdatlas=SKTextureAtlas(named: "jumpd")
    var   squatalats = SKTextureAtlas(named: "squat")
    var   squatdalats = SKTextureAtlas(named: "squatd")
    
    
    
    var   standframe=[SKTexture]()
    var   turnrightframe=[SKTexture]()
    var   turnleftframe=[SKTexture]()
    var  jumpframe=[SKTexture]()
    var   standdownframe=[SKTexture]()
    var   turnrightdframe=[SKTexture]()
    var   turnleftdframe=[SKTexture]()
    var  jumpdframe=[SKTexture]()
    var  squatframe=[SKTexture]()
    var  squatdframe=[SKTexture]()
    var    delegate:WlHumanprotocol?
    
    init()
    {
        
        let    texture=standatlas.textureNamed("stand_01.png")
        let  size=CGSizeMake(40, 40)
        print("original"+"\(size)")
        super.init(texture: texture, color:SKColor.redColor(), size: size)
       
        settextureframe("stand_", atlas: standatlas)
        settextureframe("left_", atlas: turnleftatlas)
        settextureframe("right_", atlas: turnrightatlas)
        settextureframe("jump_", atlas: jumpatlas)
        settextureframe("stand_down_", atlas: standdownatlas)
        settextureframe("leftd_", atlas: turnleftdatlas)
        settextureframe("rightd_", atlas: turnrightdatlas)
        settextureframe("jumpd_", atlas: jumpdatlas)
        settextureframe("squat_", atlas: squatalats)
        settextureframe("squatd_", atlas: squatdalats)
        createphysicsappear()
        //订阅 一个通知  外界重力发生改变的时候他需要更改重力方向的通知
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "gravitychange:", name: "gravitychangenotification", object: nil)
        
       
        
    }
    func   settextureframe(name:String,atlas:SKTextureAtlas)
    {
        let   cout  = atlas.textureNames.count
        if   name=="stand_"
        {
            
            for   i  in  1...cout
            {
                let   aname=String(format: "stand_%.2d", i)
                let   atexture=standatlas.textureNamed(aname)
                
                if   atexture.isKindOfClass(SKTexture)
                {
                    standframe.append(atexture)
                }
                
                
            }
            
            
        }
        else if  name=="left_"
        {
            for  i in 1...cout
            {
                
                let   aname=String(format: "left_%.2d", i)
                let   atexture=turnleftatlas.textureNamed(aname)
                if   atexture.isKindOfClass(SKTexture)
                {
                    turnleftframe.append(atexture)
                }
            }
            
            
        }
        else  if  name=="right_"
        {
            for  i in 1...cout
            {
                
                let   aname=String(format: "right_%.2d", i)
                let   atexture=turnrightatlas.textureNamed(aname)
                if   atexture.isKindOfClass(SKTexture)
                {
                    turnrightframe.append(atexture)
                }
            }
            
        }
        else  if  name=="jump_"
        {
            for  i in 1...cout
            {
                
                let   aname=String(format: "jump_%.2d", i)
                let   atexture=jumpatlas.textureNamed(aname)
                if   atexture.isKindOfClass(SKTexture)
                {
                    jumpframe.append(atexture)
                }
            }
        }
        else if  name == "stand_down_"
        {
            for  i in 1...cout
            {
                
                let   aname=String(format: "stand_down_%.2d", i)
                let   atexture=standdownatlas.textureNamed(aname)
                if   atexture.isKindOfClass(SKTexture)
                {
                    standdownframe.append(atexture)
                }
            }
        }
        else if  name == "leftd_"
        {
            for  i in 1...cout
            {
                
                let   aname=String(format: "leftd_%.2d", i)
                let   atexture=turnleftdatlas.textureNamed(aname)
                if   atexture.isKindOfClass(SKTexture)
                {
                    turnleftdframe.append(atexture)
                }
            }
        }
        else if  name == "rightd_"
        {
            for  i in 1...cout
            {
                
                let   aname=String(format: "rightd_%.2d", i)
                let   atexture=turnrightdatlas.textureNamed(aname)
                if   atexture.isKindOfClass(SKTexture)
                {
                    turnrightdframe.append(atexture)
                }
            }
        }
        else  if  name == "jumpd_"
        {
            for  i in 1...cout
            {
                
                let   aname=String(format: "jumpd_%.2d", i)
                let   atexture=jumpdatlas.textureNamed(aname)
                if   atexture.isKindOfClass(SKTexture)
                {
                    jumpdframe.append(atexture)
                }
            }
        }
        else  if  name == "squat_"
        {
            for  i in 1...cout
            {
                
                let   aname=String(format: "squat_%.2d", i)
                let   atexture=squatalats.textureNamed(aname)
                if   atexture.isKindOfClass(SKTexture)
                {
                    squatframe.append(atexture)
                }
            }
        }
        else  if  name == "squatd_"
        {
            for  i in 1...cout
            {
                
                let   aname=String(format: "squatd_%.2d", i)
                let   atexture=squatdalats.textureNamed(aname)
                if   atexture.isKindOfClass(SKTexture)
                {
                    squatdframe.append(atexture)
                }
            }
        }
        
        
        
    }
    
    
    
    
    func   standaction()
    {
       
        
        self.actionstate=ActionState.stand
        if   !gravityup {
       
        self.runAction(SKAction.repeatActionForever(SKAction.animateWithTextures(standframe, timePerFrame: 0.3)))
        }
        else
        {
           
            self.runAction(SKAction.repeatActionForever(SKAction.animateWithTextures(standdownframe, timePerFrame: WLHuman.perduration)))
            
        }
        
    }
    func   squataction()
    {
        
        
       
        self.actionstate=ActionState.squat
        if  !gravityup{
            self.runAction(SKAction.sequence([SKAction.group([SKAction.animateWithTextures(self.squatframe , timePerFrame:2/30)
                
                
                ]),SKAction.repeatActionForever(SKAction.animateWithTextures(standframe, timePerFrame: WLHuman.perduration))]))
        }
            //重力不是向上的
        else
        {
            self.runAction(SKAction.sequence([SKAction.group([SKAction.animateWithTextures(self.squatdframe , timePerFrame:2/30)
                
                
                ]),SKAction.repeatActionForever(SKAction.animateWithTextures(standdownframe, timePerFrame: WLHuman.perduration))]))
        }

        
        
        
    }
    
    
        //向右行走的动画
    func   turnrightaction()
    {
     
           
            self.actionstate=ActionState.right
           if  !gravityup{
            self.runAction(SKAction.sequence([SKAction.group([SKAction.animateWithTextures(self.turnrightframe , timePerFrame:2/30)
                
                
                ]),SKAction.repeatActionForever(SKAction.animateWithTextures(standframe, timePerFrame: WLHuman.perduration))]))
           }
           //重力不是向上的
        else
          {
            self.runAction(SKAction.sequence([SKAction.group([SKAction.animateWithTextures(self.turnrightdframe , timePerFrame:2/30)
                
                
                ]),SKAction.repeatActionForever(SKAction.animateWithTextures(standdownframe, timePerFrame: WLHuman.perduration))]))
        }
        
    
    }
        //zuo行走的动画
        func   turnleftaction()
        {
    
           self.actionstate=ActionState.left
            if  !gravityup{
            self.runAction(SKAction.sequence([SKAction.group([SKAction.animateWithTextures(self.turnleftframe , timePerFrame:2/30)
                
                
                ]),SKAction.repeatActionForever(SKAction.animateWithTextures(standframe, timePerFrame: WLHuman.perduration))]))
            }else
            {
                self.runAction(SKAction.sequence([SKAction.group([SKAction.animateWithTextures(self.turnleftdframe , timePerFrame:2/30)
                    
                    
                    ]),SKAction.repeatActionForever(SKAction.animateWithTextures(standdownframe, timePerFrame: WLHuman.perduration))]))
            
            }
            
            
    
        }
    
    
    
    //  跳跃的动画
    func   jumpaction()
    {
    
    self.removeAllActions()
    self.actionstate=ActionState.jump
   
        
    let   newhigh = self.delegate!.humanwilljump()
    if    maxh == 0
    {
      return
    }
        //重力向下的
        if   !gravityup{
        
        
    if  newhigh.y >  maxh - self.size.height/2.0
    {
        self.runAction(SKAction.sequence([SKAction.sequence([  SKAction.moveToY(maxh - self.size.height/2.0, duration:2/10),SKAction.animateWithTextures(self.jumpframe , timePerFrame:2/30)
            
            
            ]),SKAction.repeatActionForever(SKAction.animateWithTextures(standframe, timePerFrame: WLHuman.perduration))]))
    }
    else
    {
        self.runAction(SKAction.sequence([SKAction.sequence([  SKAction.moveToY(newhigh.y+WLHuman.jumpvalue, duration:2/10),SKAction.animateWithTextures(self.jumpframe , timePerFrame:2/30)
            
            ]),SKAction.repeatActionForever(SKAction.animateWithTextures(standframe, timePerFrame: WLHuman.perduration))]))
    }
  }
        else
        {
              if   newhigh.y <= self.size.height/2.0
            {
                self.runAction(SKAction.sequence([SKAction.sequence([  SKAction.moveToY(self.size.height/2.0, duration:2/10),SKAction.animateWithTextures(self.jumpdframe , timePerFrame:2/30)
                    
                    
                    ]),SKAction.repeatActionForever(SKAction.animateWithTextures(standdownframe, timePerFrame: WLHuman.perduration))]))

            }
            else
              {
                self.runAction(SKAction.sequence([SKAction.sequence([  SKAction.moveToY(newhigh.y-WLHuman.jumpvalue, duration:2/10),SKAction.animateWithTextures(self.jumpdframe , timePerFrame:2/30)
                    
                    
                    ]),SKAction.repeatActionForever(SKAction.animateWithTextures(standdownframe, timePerFrame: WLHuman.perduration))]))

            }
        }
      
        
   
        
       
     

    
    }
    
    func   createphysicsappear()
    {
        
        self.physicsBody = SKPhysicsBody(rectangleOfSize: self.size)
        self.physicsBody?.dynamic=true
        self.physicsBody?.contactTestBitMask = WLcategoryMask.contacspringtmask | WLcategoryMask.contacstartmask | WLcategoryMask.contacdoortmask | WLcategoryMask.contacgravitytmask
        self.physicsBody?.categoryBitMask = WLcategoryMask.contactplayermask
        self.physicsBody?.allowsRotation = false
        
        
    }
   
    //接到这个通知 我需要干什么
    func  gravitychange(noti:NSNotification)
    {
        //拿到当前通知发送过来的坐标,也就是水平线的y
            let   grap = noti.object as! CGFloat
        
            self.removeAllActions()
             //为了防止瞬间被物理引擎模拟效果先停用
            //首先看是不是站立 的
        
        
        
             self.physicsBody?.dynamic = false
             if   gravityup
             {
            
                
                 self.position.y = grap - self.size.height/2.0
                
             }
                
             else
             {
               self.position.y = grap + self.size.height/2.0
             }
        
           NSThread.sleepForTimeInterval(0.1)
          //再次启用 物理模拟
           self.delegate?.humanstateaction(self.actionstate)
     
          self.physicsBody?.dynamic = true
           print(actionstate)
   
      
        
        
    }
    
    //对象释放时
    deinit
    {
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
