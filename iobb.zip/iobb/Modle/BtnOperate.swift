//
//  BtnOperate.swift
//  iobb
//
//  Created by lw on 16/4/10.
//  Copyright © 2016年 wl. All rights reserved.
//

import UIKit
enum   OprerateType:Int
{
    case  left,right,none
}

protocol   OperateProtocol
{
    func      MoveRight()
    func      MoveLeft()
    func      StopMove()
    
}

class BtnOperate: UIButton {

    var perclicktime:NSTimeInterval=0.0
    private  var   beginclicktime:NSTimeInterval=0.0
    var   op:OprerateType?
    var   delegate:OperateProtocol?
    override init(frame: CGRect) {
        
        
        op=OprerateType.none
        super.init(frame:frame)
    
        
    }
    convenience  init(frame: CGRect,type:OprerateType) {
        self.init(frame:frame)
        op=type
       
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
   
    override   func  touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        //每次点击我时 按照当前的类型 发送不同的消息
       
        
       
        if   op==OprerateType.left
        {
            
            self.delegate?.MoveLeft()
        }
      
        else  if    op==OprerateType.right
        {
            
            self.delegate?.MoveRight()
        }
        
    }
    override    func   touchesEnded(touches: Set<UITouch>, withEvent event: UIEvent?) {
          NSThread.sleepForTimeInterval(0.1)
         self.delegate?.StopMove()
        
    }
    

    
    
    

}
