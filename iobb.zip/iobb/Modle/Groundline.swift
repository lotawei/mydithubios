//
//  groundline.swift
//  firstscene
//
//  Created by lw on 16/4/16.
//  Copyright © 2016年 lw. All rights reserved.
//

import UIKit
import  SpriteKit
class Groundline: SKSpriteNode {
      
       
    
    

}
