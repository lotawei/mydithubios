//
//  WLcategoryMask.swift
//  firstscene
//
//  Created by lw on 16/4/18.
//  Copyright © 2016年 lw. All rights reserved.
//



struct WLcategoryMask {

    //主角碰撞掩码
    static  let  contactplayermask:UInt32=0x1 << 1
    //星星
     static  let  contacstartmask:UInt32=0x2 << 2
    //弹簧
    static  let  contacspringtmask:UInt32=0x3 << 3
    //重力翻转
    static  let  contacgravitytmask:UInt32=0x4 << 4
    //门
    static  let  contacdoortmask:UInt32=0x5 << 5
}
