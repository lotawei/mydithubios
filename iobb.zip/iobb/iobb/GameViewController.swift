//
//  GameViewController.swift
//  iobb
//
//  Created by lotawei on 16/3/30.
//  Copyright (c) 2016年 wl. All rights reserved.
//

import UIKit
import SpriteKit

class GameViewController: UIViewController {

    override func viewDidLoad() {
        let    skv = self.view as!  SKView
        skv.showsDrawCount=true
        skv.showsFPS=true
        skv.showsNodeCount=true
        skv.presentScene(SetingScene())
        
    }





    override func prefersStatusBarHidden() -> Bool {
        return true
    }
}
