//
//  GameScene.swift
//  iobb
//
//  Created by lotawei on 16/3/30.
//  Copyright (c) 2016年 wl. All rights reserved.
//   主界面

import SpriteKit

class GameMainScene: SKScene {
    //是否创建
    var    iscreate=false
    //使用sknode
    var    background=SKNode()
    //创建一个精灵作为背景
    var    backsprite:SKSpriteNode!
    //创建图标精灵
    var    iconsprite:SKSpriteNode!
    //图标与最上方 的间距
    let  padding:CGFloat=50.0
    
    //开始游戏的button
    var    btnstart:UIButton!
    //设置
    var   btnsetting:UIButton!
    //帮助
    var    btnhelp:UIButton!
    let   width:CGFloat=200
    let    height:CGFloat=40
    //版权声明
    var    aboutinfo:UILabel!
    //渐变层
    var  gradientlayer:CAGradientLayer!
    let    aboutstring="Make happiness by heart "
    
    override func  didMoveToView(view: SKView) {
        self.size=view.frame.size
        createcontent()
        
    }
    func  createcontent()
    {
        if  iscreate
        {
            return
        }
        //设置背景sprite
        backsprite=SKSpriteNode(imageNamed: "back")
        backsprite.zPosition=1
        backsprite.anchorPoint=CGPointMake(0.5, 1)
        backsprite.position=CGPointMake(CGRectGetMidX((view?.frame)!),CGRectGetMaxY((view?.frame)!))
        background.addChild(backsprite)
        /**
        设置我们的图标
        **/
        iconsprite=SKSpriteNode(imageNamed: "icon")
        iconsprite.zPosition=1
        iconsprite.anchorPoint=CGPointMake(0.5, 1)
        iconsprite.position=CGPointMake(CGRectGetMidX((view?.frame)!), CGRectGetMaxY((view?.frame)!)-padding)
        
        
        background.addChild(iconsprite)
        //为其添加动画
         iconsprite.anchorPoint=CGPointMake(0.5, 0.5)
        
        iconsprite.runAction(SKAction.repeatActionForever(SKAction.group([
            SKAction.rotateByAngle(0.5, duration: 0.5)
            ])))
        //开始按钮

        
        let   x:CGFloat=CGRectGetMidX((view?.frame)!)-width/2
        let   y:CGFloat=iconsprite.position.y-iconsprite.size.height-padding*2
        btnstart=UIButton(frame: CGRectMake(x, y, width, height))
        btnstart.backgroundColor=UIColor.blackColor()
        btnstart.alpha=0.5
        btnstart.setTitle("开始", forState: .Normal)
        btnstart.addTarget(self, action:#selector(GameMainScene.StartPlayScene), forControlEvents: .TouchUpInside)
        view?.addSubview(btnstart)
        //设置按钮
     
        let   ys:CGFloat=CGRectGetMinY(btnstart.frame)+padding
        btnsetting=UIButton(frame: CGRectMake(x, ys, width, height))
        btnsetting.backgroundColor=UIColor.blackColor()
        btnsetting.alpha=0.5
        btnsetting.setTitle("设置", forState: .Normal)
        btnsetting.addTarget(self, action:#selector(GameMainScene.StartSetScene), forControlEvents: .TouchUpInside)
        view?.addSubview(btnsetting)
        
        //帮助按钮
        let   yh:CGFloat=CGRectGetMinY(btnsetting.frame)+padding
        btnhelp=UIButton(frame: CGRectMake(x, yh, width, height))
        btnhelp.backgroundColor=UIColor.blackColor()
        btnhelp.alpha=0.5
        btnhelp.setTitle("帮助", forState: .Normal)
        btnhelp.addTarget(self, action:#selector(GameMainScene.StartHelpScene), forControlEvents: .TouchUpInside)
        view?.addSubview(btnhelp)
        
        //创建动态变化的文字
        let   ya:CGFloat=CGRectGetMinY(btnhelp.frame)+padding*1.5
        aboutinfo=UILabel(frame: CGRectMake(x, ya, width, height-10))
        aboutinfo.text=aboutstring
        aboutinfo.font=UIFont(name: aboutstring, size: 12)
        aboutinfo.sizeToFit()
        aboutinfo.textColor=UIColor.whiteColor()
        view?.addSubview(aboutinfo)
//        gradientlayer=CAGradientLayer()
//        gradientlayer.frame=aboutinfo.frame
//        
//        gradientlayer.colors=[randomcolor(),randomcolor(),randomcolor(),randomcolor()]
//        view?.layer.addSublayer(gradientlayer)
//        
//        gradientlayer.mask=aboutinfo.layer
//        
//        aboutinfo.frame=gradientlayer.bounds
//        
//        let     link=CADisplayLink.init(target: self, selector: "textcolorchange")
//        link.addToRunLoop(NSRunLoop.mainRunLoop(), forMode: NSDefaultRunLoopMode)
//        
//
        
        
        
        
        addChild(background)
        
        iscreate=true
    }
    //创建到游戏界面
    func   StartPlayScene()
    {
        
        
        let  newpalyscene=PlayScene()
        newpalyscene.name="PlayScene"
        //呈现新的场景时 移除各种按钮
        removeallbtn()
        view?.presentScene(newpalyscene, transition:SKTransition.moveInWithDirection(.Right, duration: 1))
    }
    
    //设置界面
    
    func     StartSetScene()
    {
        
        let  newpalyscene=SetingScene()
        newpalyscene.name="SetingScene"
        //呈现新的场景时 移除各种按钮
        removeallbtn()
        view?.presentScene(newpalyscene, transition:SKTransition.moveInWithDirection(.Right, duration: 1))
        
        
    }
    //帮助界面
    
    func     StartHelpScene()
    {
        
        let  newpalyscene=HelpScene()
        newpalyscene.name="HelpScene"
        //呈现新的场景时 移除各种按钮
        removeallbtn()
        view?.presentScene(newpalyscene, transition:SKTransition.moveInWithDirection(.Right, duration: 2))
        
        
    }
    
  
    //随机颜色
    func   randomcolor()->UIColor
    {
        let    r=arc4random()%255
        let    g=arc4random()%255
           let    b=arc4random()%255
        return    UIColor.init(red:CGFloat(r), green:CGFloat(g), blue:CGFloat(b), alpha: 1)
    }
    
//    func   textcolorchange()
//    {
//        gradientlayer.colors=[randomcolor(),randomcolor(),randomcolor(),randomcolor()]
//        aboutinfo.backgroundColor=randomcolor()
//    
//    }
    
    
    
    
    
    //在切换场景时 移除btn
    
    func   removeallbtn()
    {
        btnstart.removeFromSuperview()
        
        btnsetting.removeFromSuperview()
        btnhelp.removeFromSuperview()
        aboutinfo.removeFromSuperview()
        
    }
    
    
    
    
}
